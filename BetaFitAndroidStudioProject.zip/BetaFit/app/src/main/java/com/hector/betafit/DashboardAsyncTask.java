package com.hector.betafit;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;



public class DashboardAsyncTask extends AsyncTask<Void, Void, ArrayList<JSONObject>> {
    private com.hector.betafit.UserActivity instanciaClasePrincipal;
    int progreso = 1;

    public DashboardAsyncTask(com.hector.betafit.UserActivity instanciaClasePrincipal){
        this.instanciaClasePrincipal= instanciaClasePrincipal;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        instanciaClasePrincipal.scrollView.setVisibility(View.GONE);
        instanciaClasePrincipal.progressBar.setVisibility(View.VISIBLE);
        instanciaClasePrincipal.infoTextView.setVisibility(View.VISIBLE);

        instanciaClasePrincipal.tTempCol1.removeAllViews();
        instanciaClasePrincipal.tTempCol2.removeAllViews();
        instanciaClasePrincipal.tTempCol3.removeAllViews();
        instanciaClasePrincipal.tFrqCol1.removeAllViews();
        instanciaClasePrincipal.tFrqCol2.removeAllViews();
        instanciaClasePrincipal.tFrqCol3.removeAllViews();
    }

    @Override
    protected ArrayList<JSONObject> doInBackground(Void... voids) {
        JSONObject jsonObj = null;
        String jsonString = null;
        ArrayList<JSONObject> jsonObjectsArrayList = new ArrayList<>();
        try {
            /*InputStreamReader inputStreamReader = new InputStreamReader(instanciaClasePrincipal.getAssets().open("measurements.json"));
            BufferedReader r = new BufferedReader(inputStreamReader);
            int leido = 0;
            String jsonString = "";
            while (leido!=-1){
                leido = r.read();
                char letra = (char) leido;
                jsonString+=letra;
            }
            r.close();
            */
            publishProgress();
            jsonString = instanciaClasePrincipal.httpConnectionHandler.get(HTTPConnectionHandler.SETUP_MEASUREMENT);
            SystemClock.sleep(1000);
            Log.d("PRUEBAS", "Contenido fichero measurements.json: " + jsonString);
            jsonObj = new JSONObject(jsonString);
            jsonObjectsArrayList.add(jsonObj);
            // Getting JSON Object "pasos"
            JSONObject pasosJson = jsonObj.getJSONObject("pasos");
            JSONArray muestrasPasosArray = pasosJson.getJSONArray("muestras");

            //Representación gráfica pasos
            configurarGraficoPasos(muestrasPasosArray);

            //Recuperación ficheros usersettings y generalsettings
            jsonObj = new JSONObject(instanciaClasePrincipal.httpConnectionHandler.get(HTTPConnectionHandler.GET_UMBRALES));
            jsonObjectsArrayList.add(jsonObj);
            jsonObj = new JSONObject(instanciaClasePrincipal.httpConnectionHandler.get(HTTPConnectionHandler.GET_USERSETTINGS));
            jsonObjectsArrayList.add(jsonObj);


        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonObjectsArrayList;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        progreso++;
        if(progreso>100){
            progreso=1;
        }
        instanciaClasePrincipal.progressBar.setProgress(progreso);
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(ArrayList<JSONObject> jsonObjectArrayList) {
        super.onPostExecute(jsonObjectArrayList);

        try {
            //instanciaClasePrincipal.graficoPasos.animateXY(1000,1000);
            //Log.d("PRUEBAS", "MES GRAFICA" + jsonObjectArrayList.get(0).getJSONObject("pasos").getString("mes"));
            instanciaClasePrincipal.mesTextView.setText(jsonObjectArrayList.get(0).getJSONObject("pasos").getString("mes"));
            // Representación temperatura
            representarTabla(jsonObjectArrayList.get(0).getJSONArray("temperaturas"), 0);
            // Representación frecuencia cardiaca
            representarTabla(jsonObjectArrayList.get(0).getJSONArray("frecuenciacardiaca"), 1);

            //Obtencion información de usuario
            JSONObject infoIDUsuarioJson = jsonObjectArrayList.get(2).getJSONObject("ID");
            String infoUsuario;
            if (!infoIDUsuarioJson.get("nombre").equals("-")) {
                JSONObject infoIMCUsuarioJson = jsonObjectArrayList.get(2).getJSONObject("IMC");
                JSONObject infoUmbralesJson = jsonObjectArrayList.get(1).getJSONObject("alarmas");
                infoUsuario = "Nombre: " + infoIDUsuarioJson.get("nombre") + "\n";
                infoUsuario += "Apellidos: " + infoIDUsuarioJson.getString("apellido1") + " " + infoIDUsuarioJson.getString("apellido2") + "\n";
                infoUsuario += "Alarmas definidas\n";
                infoUsuario += "Temperatura: " + infoUmbralesJson.getString("temperatura") + " ºC. Frec. cardiaca: " + infoUmbralesJson.getString("frecuenciacardiaca") + " ppmin\n";
                infoUsuario += "Información IMC\n";
                double peso,altura,imc;
                peso = infoIMCUsuarioJson.getDouble("peso");
                altura = infoIMCUsuarioJson.getDouble("altura");
                imc = peso/(altura*altura);
                DecimalFormat formato = new DecimalFormat("##.##");
                infoUsuario += "Altura: " + altura + " m. Peso: " + peso + " kg\n";
                infoUsuario += "IMC = " + formato.format(imc) + " " + valorIMC(imc);
            } else {
                infoUsuario = "No hay información disponible. Define primero un usuario";
            }
            instanciaClasePrincipal.infoUsuarios.setText(infoUsuario);

            instanciaClasePrincipal.progressBar.setVisibility(View.GONE);
            instanciaClasePrincipal.infoTextView.setVisibility(View.GONE);
            instanciaClasePrincipal.scrollView.setVisibility(View.VISIBLE);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private String valorIMC (double imc){
        String valor;
        if(imc<18.5){
            valor = "(Bajo peso)";
        }else if (imc<24.9){
            valor = "(Normal)";
        }else if (imc<29.9){
            valor = "(Sobrepeso)";
        } else{
            valor = "(Obesidad)";
        }
        return valor;
    }

    private ArrayList<BarEntry> dataValues1(JSONArray jsonArray) throws JSONException {
        ArrayList<BarEntry> yValues = new ArrayList<BarEntry>();
        for (int i = 0; i < jsonArray.length(); i++){
            JSONObject c = null;
            c = jsonArray.getJSONObject(i);
            yValues.add(new BarEntry(i+1, c.getInt("valor")));
        }
        return yValues;
    }

    private class MyValueFormatter implements IValueFormatter{
        @Override
        public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
            int newValue = (int) value;
            return String.valueOf(newValue);
        }
    }

    private void configurarGraficoPasos (JSONArray jsonArray) throws JSONException {
        BarDataSet valoresPasos = new BarDataSet(dataValues1(jsonArray),"Número de pasos por día");
        valoresPasos.setColor(Color.parseColor("#3fb25d"));
        valoresPasos.setValueFormatter(new MyValueFormatter());
        BarData data = new BarData();
        data.addDataSet(valoresPasos);
        instanciaClasePrincipal.graficoPasos.setData(data);
        Description description = new Description();
        description.setText("");
        XAxis xAxis = instanciaClasePrincipal.graficoPasos.getXAxis();
        xAxis.setLabelCount(jsonArray.length());
        YAxis yAxisRight = instanciaClasePrincipal.graficoPasos.getAxisRight();
        yAxisRight.setEnabled(false);
        instanciaClasePrincipal.graficoPasos.setDescription(description);
        instanciaClasePrincipal.graficoPasos.invalidate();

        instanciaClasePrincipal.graficoPasos.setNoDataText("ERROR: Fallo al cargar los datos");
    }

    private void representarTabla (JSONArray jsonArray, int tipoTabla) throws JSONException {
        for (int i = 0; i<jsonArray.length(); i++){
            JSONObject c = null;
            c = jsonArray.getJSONObject(i);
            TextView textView1 = new TextView(instanciaClasePrincipal);
            textView1.setText(String.valueOf(i+1));
            textView1.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

            TextView textView2 = new TextView(instanciaClasePrincipal);
            textView2.setText(c.getString("tiempo").replace('T',' '));
            textView2.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

            TextView textView3 = new TextView(instanciaClasePrincipal);
            textView3.setText(c.getString("valor"));
            textView3.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

            if(c.getBoolean("alarma")){
                textView1.setTextColor(Color.RED);
                textView2.setTextColor(Color.RED);
                textView3.setTextColor(Color.RED);
            } else {
                textView1.setTextColor(Color.BLACK);
                textView2.setTextColor(Color.BLACK);
                textView3.setTextColor(Color.BLACK);
            }
            if(tipoTabla == 0){
                instanciaClasePrincipal.tTempCol1.addView(textView1);
                instanciaClasePrincipal.tTempCol2.addView(textView2);
                instanciaClasePrincipal.tTempCol3.addView(textView3);
            } else{
                instanciaClasePrincipal.tFrqCol1.addView(textView1);
                instanciaClasePrincipal.tFrqCol2.addView(textView2);
                instanciaClasePrincipal.tFrqCol3.addView(textView3);
            }
        }
    }

}
