package com.hector.betafit;

import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.CookieManager;
import java.net.HttpCookie;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HTTPConnectionHandler implements Serializable {
    private String dirIP;
    static final String COOKIES_HEADER = "Set-Cookie";
    static CookieManager msCookieManager;
    public static final String LOGIN_OPERATION = "LOGIN";
    public static final String SETUP_MEASUREMENT = "MEASUREMENT";
    public static final String PASSWORD_CHANGE = "PASSWORD";
    public static final String SETTING_UMBRAL = "UMBRAL";
    public static final String LOG_OUT = "LOGOUT";
    public static final String MODIFY_USER = "USER";
    public static final String GET_USERSETTINGS = "USER_SETTINGS";
    public static final String GET_UMBRALES = "GET_UMBRALES";

    public HTTPConnectionHandler (String dirIP){
        this.dirIP = dirIP;
        msCookieManager = new CookieManager();
    }

    public String post(String typeOperation, HashMap<String,String> params) {
        String paramsReady = prepareParams(params);
        HttpURLConnection conn = null;
        StringBuilder result = new StringBuilder();

        try{
            // Create the HttpURLConnection, open the connection, and send the POST parameters.
            URL urlObj = selectURL(typeOperation);
            conn = (HttpURLConnection) urlObj.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            if((msCookieManager.getCookieStore().getCookies().size()>0)&&(typeOperation!=LOGIN_OPERATION)){
                Log.d("PRUEBAS", "COOKIES GUARDADA A PUNTO DE ENVIAR: " + msCookieManager.getCookieStore().getCookies().toString());
                conn.setRequestProperty("Cookie", TextUtils.join(";",msCookieManager.getCookieStore().getCookies()));
            }
            //conn.setRequestProperty("Accept-Charset", "UTF-8");

            //conn.connect();

            DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
            wr.writeBytes(paramsReady);
            wr.flush();
            wr.close();

            // Receive the result that the server sends back
            if(typeOperation.equals(LOGIN_OPERATION)){
                if(conn.getResponseCode()==301){ // LOGIN CORRECTO
                    Log.d("PRUEBAS", "Login correcto");
                    result.append("LOGIN CORRECTO");

                    // Recibo la cookie
                    Map<String, List<String>> headerFields = conn.getHeaderFields();
                    List<String> cookiesHeader = headerFields.get(COOKIES_HEADER);

                    if (cookiesHeader != null) {
                        for (String cookie : cookiesHeader) {
                            msCookieManager.getCookieStore().add(null, HttpCookie.parse(cookie).get(0));
                        }
                    }
                    Log.d("PRUEBAS", msCookieManager.getCookieStore().getCookies().toString());

                }else { // LOGIN INCORRECTO
                    Log.d("PRUEBAS", "Login incorrecto");
                    result.append("LOGIN INCORRECTO");
                }
            }
            if(conn.getResponseCode()==401){
                result.append("Fallo en la autenticación en el servidor");
            }
            else{
                InputStream in = new BufferedInputStream(conn.getInputStream());
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));

                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }

                Log.d("PRUEBAS", "result from server: " + result.toString());
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        return result.toString();

    }

    public String get (String typeOperation){
        HttpURLConnection conn = null;
        StringBuilder result = new StringBuilder();
        URL urlObj = selectURL(typeOperation);
        try {
            conn = (HttpURLConnection) urlObj.openConnection();
            if(msCookieManager.getCookieStore().getCookies().size()>0){
                Log.d("PRUEBAS", "COOKIES GUARDADA A PUNTO DE ENVIAR: " + msCookieManager.getCookieStore().getCookies().toString());
                conn.setRequestProperty("Cookie", TextUtils.join(";",msCookieManager.getCookieStore().getCookies()));
            }
            InputStream in = conn.getInputStream();

            InputStreamReader isw = new InputStreamReader(in);

            int data = isw.read();
            while (data != -1) {
                result.append((char)data);
                data = isw.read();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return result.toString();
    }

    private String prepareParams (HashMap<String,String> params){
        StringBuilder sbParams = new StringBuilder();
        int i = 0;
        for (String key : params.keySet()) {
            try {
                if (i != 0){
                    sbParams.append("&");
                }
                sbParams.append(key).append("=")
                        .append(URLEncoder.encode(params.get(key), "UTF-8"));

            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            i++;
        }
        return sbParams.toString();
    }

    private URL selectURL (String typeOperation){
        URL url = null;
        String uri = "http://"+dirIP+"/app";
        switch(typeOperation){
            case LOGIN_OPERATION:
                uri += "/login";
                break;
            case SETUP_MEASUREMENT:
                uri += "/measurements";
                break;
            case PASSWORD_CHANGE:
                uri += "/password";
                break;
            case SETTING_UMBRAL:
                uri += "/generalsettings";
                break;
            case MODIFY_USER:
                uri += "/usersettings";
                break;
            case LOG_OUT:
                uri += "/logout";
                break;
            case GET_USERSETTINGS:
                uri = "http://"+dirIP+"/data/usersettings";
                break;
            case GET_UMBRALES:
                uri = "http://"+dirIP+"/data/generalsettings";
                break;
            default:
                break;
        }
        try {
            url = new URL(uri);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return url;
    }


}
