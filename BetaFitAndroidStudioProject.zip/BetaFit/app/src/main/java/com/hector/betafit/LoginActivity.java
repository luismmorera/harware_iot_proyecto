package com.hector.betafit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.hector.betafit.logManagement.LogInAsyncTask;

public class LoginActivity extends AppCompatActivity {
    EditText user, password, dirIp;
    public HTTPConnectionHandler httpConnectionHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user = findViewById(R.id.username);
        password = findViewById(R.id.password);
        dirIp = findViewById(R.id.editTextDirIP);

    }

    public void manejadorLogin(View v){
        if(comprobarConexion()){
            if((user.getText().length()!=0) && (password.getText().length() != 0)&& (dirIp.getText().length() != 0)){
                httpConnectionHandler = new HTTPConnectionHandler(dirIp.getText().toString());
                LogInAsyncTask loginAsyncTask = new LogInAsyncTask(this);
                Log.d("PRUEBAS","TAREA ASINCRONA");
                loginAsyncTask.execute(user.getText().toString(),password.getText().toString());
            } else{
                Toast.makeText(this,"Rellene todos los campos", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(this,"Conectese a la misma Wifi que el wearable", Toast.LENGTH_SHORT).show();
        }

    }

    private boolean comprobarConexion(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return (networkInfo!=null)&&(networkInfo.isConnected());
    }
}