package com.hector.betafit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.hector.betafit.credentialsManagement.CredentialsDialog;
import com.hector.betafit.logManagement.LogOutAsyncTask;
import com.hector.betafit.umbralManagement.UmbralDialog;
import com.hector.betafit.userSettingsManagement.UserSettingsDialog;


public class UserActivity extends AppCompatActivity {
    com.hector.betafit.UserActivity actividad = this;
    public Toolbar myToolbar;
    ProgressBar progressBar;
    protected BarChart graficoPasos;
    protected ScrollView scrollView;
    protected TextView infoTextView, mesTextView, infoUsuarios;
    protected TableLayout tablaTemperatura, tablaFrecuencia;
    protected LinearLayout tTempCol1 ,tTempCol2, tTempCol3;
    protected LinearLayout tFrqCol1 ,tFrqCol2, tFrqCol3;
    public HTTPConnectionHandler httpConnectionHandler;
    private String nombreUsuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        myToolbar = findViewById(R.id.myToolbar);
        progressBar = findViewById(R.id.progressBar);
        graficoPasos = findViewById(R.id.graficoPasos);
        scrollView = findViewById(R.id.scrollView);
        infoTextView = findViewById(R.id.tvInfo);
        mesTextView = findViewById(R.id.mesActual);
        tablaTemperatura = findViewById(R.id.tablaTemperaturas);
        tablaFrecuencia = findViewById(R.id.tablaFrecuencias);
        tTempCol1 = findViewById(R.id.tTempCol1);
        tTempCol2 = findViewById(R.id.tTempCol2);
        tTempCol3 = findViewById(R.id.tTempCol3);
        tFrqCol1 = findViewById(R.id.tFrqCol1);
        tFrqCol2 = findViewById(R.id.tFrqCol2);
        tFrqCol3 = findViewById(R.id.tFrqCol3);
        infoUsuarios = findViewById(R.id.infoUsuarios);
        httpConnectionHandler = (HTTPConnectionHandler) getIntent().getSerializableExtra("httpHandler");
        nombreUsuario = (String) getIntent().getStringExtra("nombreUsuario");
        myToolbar.setTitle("Hola " + nombreUsuario);
        setSupportActionBar(myToolbar);
        new DashboardAsyncTask(this).execute();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.barraherramientas,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.opcionesUsuario:
                UserSettingsDialog userDialog = new UserSettingsDialog(this);
                userDialog.show(getSupportFragmentManager(),"UserDialog");
                return true;
            case R.id.opcionesUmbrales:
                UmbralDialog umbralDialog = new UmbralDialog(this);
                umbralDialog.show(getSupportFragmentManager(),"UmbralDialog");
                return true;
            case R.id.opcionesCambioContraseña:
                CredentialsDialog passwordDialog = new CredentialsDialog(this);
                passwordDialog.show(getSupportFragmentManager(),"PasswordDialog");
                return true;
            case R.id.opcionesLogOut:
                super.onBackPressed();
                LogOutAsyncTask logOutAsyncTask = new LogOutAsyncTask(actividad);
                logOutAsyncTask.execute();
                return true;
            case R.id.opcionesActualizar:
                new DashboardAsyncTask(this).execute();
                return true;
            default: return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Cierre sesión para volver atrás", Toast.LENGTH_SHORT).show();
    }
}