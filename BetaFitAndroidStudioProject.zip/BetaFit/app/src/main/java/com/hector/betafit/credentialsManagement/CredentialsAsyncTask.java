package com.hector.betafit.credentialsManagement;

import android.os.AsyncTask;
import android.util.Log;

import com.hector.betafit.HTTPConnectionHandler;

import java.util.HashMap;

public class CredentialsAsyncTask  extends AsyncTask<String, Integer, String> {
    private com.hector.betafit.UserActivity instanciaClasePrincipal;
    private String nuevoUsuario;


    public CredentialsAsyncTask(com.hector.betafit.UserActivity instanciaClasePrincipal){
        this.instanciaClasePrincipal = instanciaClasePrincipal;
    }

    @Override
    protected String doInBackground(String... params) {
        HashMap<String,String> paramsPOST = new HashMap<>();
        nuevoUsuario = params[0];
        paramsPOST.put("usr",params[0]);
        paramsPOST.put("psw",params[1]);
        String result = instanciaClasePrincipal.httpConnectionHandler.post(HTTPConnectionHandler.PASSWORD_CHANGE, paramsPOST);

        return result;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        Log.d("PRUEBAS","CAMBIO CONTRASEÑA. CONTENIDO DE LA RESPUESTA" + s);
        instanciaClasePrincipal.myToolbar.setTitle("Hola " + nuevoUsuario);
    }

}

