package com.hector.betafit.credentialsManagement;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.hector.betafit.R;
import com.hector.betafit.UserActivity;

public class CredentialsDialog extends DialogFragment {
    private UserActivity instanciaClasePrincipal;
    public CredentialsDialog(UserActivity instanciaClasePrincipal){
        super();
        this.instanciaClasePrincipal = instanciaClasePrincipal;
    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        View view = getActivity().getLayoutInflater().inflate(R.layout.password_dialog, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle("Cambio de contraseña");
        builder.setView(view);

        EditText usuario = view.findViewById(R.id.etUsuarioPassword);
        EditText newPassword = view.findViewById(R.id.etPassword2);
        EditText againPassword = view.findViewById(R.id.etPassword3);

        builder.setNegativeButton("Cancelar", null);
        builder.setPositiveButton("Actualizar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if((usuario.getText().length() != 0) && (newPassword.getText().length() != 0) && (againPassword.getText().length() != 0)){
                    if(newPassword.getText().toString().equals(againPassword.getText().toString()) ){
                        CredentialsAsyncTask passwordAsyncTask = new CredentialsAsyncTask(instanciaClasePrincipal);
                        passwordAsyncTask.execute(usuario.getText().toString(),newPassword.getText().toString());
                    }else{
                        Toast.makeText(getActivity(),"Las contraseñas no son iguales", Toast.LENGTH_SHORT).show();
                    }
                } else{
                    Toast.makeText(getActivity(),"Rellene todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return builder.create();
    }
}
