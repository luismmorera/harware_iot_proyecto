package com.hector.betafit.logManagement;

import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.hector.betafit.HTTPConnectionHandler;
import com.hector.betafit.UserActivity;

import java.util.HashMap;

public class LogInAsyncTask  extends AsyncTask<String, Integer, String> {
    private com.hector.betafit.LoginActivity instanciaClasePrincipal;
    private String nombreUsuario;

    public LogInAsyncTask(com.hector.betafit.LoginActivity instanciaClasePrincipal){
        this.instanciaClasePrincipal = instanciaClasePrincipal;
    }

    @Override
    protected String doInBackground(String... params) {
        HashMap<String,String> paramsPOST = new HashMap<>();
        nombreUsuario = params[0];
        paramsPOST.put("uname",params[0]);
        paramsPOST.put("psw",params[1]);
        String result = instanciaClasePrincipal.httpConnectionHandler.post(HTTPConnectionHandler.LOGIN_OPERATION, paramsPOST);

        return result;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        Log.d("PRUEBAS","CONTENIDO DE LA RESPUESTA" + s);
        if(s.equals("LOGIN CORRECTO")){
            Intent intent = new Intent(instanciaClasePrincipal, UserActivity.class);
            intent.putExtra("httpHandler", instanciaClasePrincipal.httpConnectionHandler);
            intent.putExtra("nombreUsuario", nombreUsuario);
            instanciaClasePrincipal.startActivity(intent);
        }else{
            Toast.makeText(instanciaClasePrincipal, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
        }
    }

}
