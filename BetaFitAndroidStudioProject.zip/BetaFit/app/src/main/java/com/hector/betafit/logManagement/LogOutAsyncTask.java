package com.hector.betafit.logManagement;

import android.os.AsyncTask;
import android.util.Log;

import com.hector.betafit.HTTPConnectionHandler;

import java.util.HashMap;

public class LogOutAsyncTask  extends AsyncTask<String, Integer, String> {
    private com.hector.betafit.UserActivity instanciaClasePrincipal;


    public LogOutAsyncTask(com.hector.betafit.UserActivity instanciaClasePrincipal){
        this.instanciaClasePrincipal = instanciaClasePrincipal;
    }

    @Override
    protected String doInBackground(String... params) {
        HashMap<String,String> paramsPOST = new HashMap<>();
        paramsPOST.put("logout","logout");

        String result = instanciaClasePrincipal.httpConnectionHandler.post(HTTPConnectionHandler.LOG_OUT, paramsPOST);

        return result;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        Log.d("PRUEBAS","CAMBIO USUARIO. CONTENIDO DE LA RESPUESTA" + s);
    }

}