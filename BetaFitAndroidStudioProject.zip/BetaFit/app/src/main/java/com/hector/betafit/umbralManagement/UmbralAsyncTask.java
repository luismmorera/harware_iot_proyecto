package com.hector.betafit.umbralManagement;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.hector.betafit.HTTPConnectionHandler;

import java.util.HashMap;

public class UmbralAsyncTask  extends AsyncTask<String, Integer, String> {
    private com.hector.betafit.UserActivity instanciaClasePrincipal;


    public UmbralAsyncTask(com.hector.betafit.UserActivity instanciaClasePrincipal){
        this.instanciaClasePrincipal = instanciaClasePrincipal;
    }

    @Override
    protected String doInBackground(String... params) {
        HashMap<String,String> paramsPOST = new HashMap<>();
        paramsPOST.put("temperatura",params[0]);
        paramsPOST.put("frecuencia",params[1]);
        String result = instanciaClasePrincipal.httpConnectionHandler.post(HTTPConnectionHandler.SETTING_UMBRAL, paramsPOST);

        return result;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        Log.d("PRUEBAS","ESTABLECER UMBRALES. CONTENIDO DE LA RESPUESTA" + s);
        Toast.makeText(instanciaClasePrincipal, "Actualiza para mostrar los nuevos datos", Toast.LENGTH_SHORT).show();

    }

}