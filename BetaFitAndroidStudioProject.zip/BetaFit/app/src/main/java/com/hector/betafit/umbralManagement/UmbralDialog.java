package com.hector.betafit.umbralManagement;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.hector.betafit.R;
import com.hector.betafit.UserActivity;

public class UmbralDialog extends DialogFragment {
    private UserActivity instanciaClasePrincipal;
    public UmbralDialog(UserActivity instanciaClasePrincipal){
        super();
        this.instanciaClasePrincipal = instanciaClasePrincipal;
    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        View view = getActivity().getLayoutInflater().inflate(R.layout.umbral_dialog, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle("Definición de valores umbrales");
        builder.setView(view);

        EditText umbralTemperatura = view.findViewById(R.id.etUsuarioPassword);
        EditText umbralFrecuencia = view.findViewById(R.id.etPassword);

        builder.setNegativeButton("Cancelar", null);
        builder.setPositiveButton("Actualizar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if((umbralTemperatura.getText().length() != 0) && (umbralFrecuencia.getText().length() != 0) ){
                    UmbralAsyncTask umbralAsyncTask = new UmbralAsyncTask(instanciaClasePrincipal);
                    umbralAsyncTask.execute(umbralTemperatura.getText().toString(),umbralFrecuencia.getText().toString());
                } else{
                    Toast.makeText(getActivity(),"Rellene todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return builder.create();
    }
}
