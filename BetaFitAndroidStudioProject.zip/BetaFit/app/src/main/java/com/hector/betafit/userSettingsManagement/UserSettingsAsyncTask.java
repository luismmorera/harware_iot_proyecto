package com.hector.betafit.userSettingsManagement;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.hector.betafit.HTTPConnectionHandler;

import java.util.HashMap;

public class UserSettingsAsyncTask  extends AsyncTask<String, Integer, String> {
    private com.hector.betafit.UserActivity instanciaClasePrincipal;


    public UserSettingsAsyncTask(com.hector.betafit.UserActivity instanciaClasePrincipal){
        this.instanciaClasePrincipal = instanciaClasePrincipal;
    }

    @Override
    protected String doInBackground(String... params) {
        HashMap<String,String> paramsPOST = new HashMap<>();
        paramsPOST.put("nombre",params[0]);
        paramsPOST.put("apellido1",params[1]);
        paramsPOST.put("apellido2",params[2]);
        paramsPOST.put("altura",params[3]);
        paramsPOST.put("peso",params[4]);
        String result = instanciaClasePrincipal.httpConnectionHandler.post(HTTPConnectionHandler.MODIFY_USER, paramsPOST);

        return result;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        Log.d("PRUEBAS","CAMBIO USUARIO. CONTENIDO DE LA RESPUESTA" + s);
        Toast.makeText(instanciaClasePrincipal, "Actualiza para mostrar los nuevos datos", Toast.LENGTH_SHORT).show();
    }

}