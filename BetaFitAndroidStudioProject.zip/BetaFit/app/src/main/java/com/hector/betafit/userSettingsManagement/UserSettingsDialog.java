package com.hector.betafit.userSettingsManagement;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.hector.betafit.R;

public class UserSettingsDialog extends DialogFragment {
    private com.hector.betafit.UserActivity instanciaClasePrincipal;
    public UserSettingsDialog(com.hector.betafit.UserActivity instanciaClasePrincipal){
        super();
        this.instanciaClasePrincipal = instanciaClasePrincipal;
    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        View view = getActivity().getLayoutInflater().inflate(R.layout.user_dialog, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle("Datos del usuario");
        builder.setView(view);

        EditText nombre = view.findViewById(R.id.etNombre);
        EditText primerApellido = view.findViewById(R.id.etPrimerApellido);
        EditText segundoApellido = view.findViewById(R.id.etSegundoApellido);
        EditText peso = view.findViewById(R.id.etPassword);
        EditText altura = view.findViewById(R.id.etUsuarioPassword);

        builder.setNegativeButton("Cancelar", null);
        builder.setPositiveButton("Actualizar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if((nombre.getText().length() != 0) && (primerApellido.getText().length() != 0) && (segundoApellido.getText().length() != 0)
                        && (peso.getText().length() != 0) && (altura.getText().length() != 0)){
                    UserSettingsAsyncTask userSettingsAsyncTask = new UserSettingsAsyncTask(instanciaClasePrincipal);
                    userSettingsAsyncTask.execute(nombre.getText().toString(), primerApellido.getText().toString(), segundoApellido.getText().toString(), altura.getText().toString(), peso.getText().toString());
                } else{
                    Toast.makeText(getActivity(),"Rellene todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return builder.create();
    }
}
